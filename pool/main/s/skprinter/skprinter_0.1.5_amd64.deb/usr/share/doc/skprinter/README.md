# skprinter (Debian package)

SKPrinter on the appliance: renders SkyMob SVG label templates and prints them
as ZPL. Runs as a systemd service alongside `skbridge`.

A collector can then send its print jobs to the bridge, and a shop no longer
needs a Windows machine standing by just to produce labels.

## What differs from the Windows build

The Windows service is built around a print queue it intercepts; this one is
built around an HTTP request that carries everything:

| | Windows | here |
|---|---|---|
| how a job arrives | a print queue spools XPS into a RAW port, **or** HTTP | HTTP only |
| what a job carries | a piece id to look up | the label data itself |
| passthrough of a captured job | yes | nothing to capture |
| rendering | XPS, rasterized by the printer driver | rasterized here, sent as one `^GF` |
| tray icon, printer provisioning | yes | no |
| local databases | label store + print ledger | none |
| the console | served by this service | served by `skbridge` |
| what a printer entry names | a print queue | an address |

The label binder is the same code, so a template renders the same on both. The
settings files are not interchangeable: each host reads its own shape and
rejects a file written for the other.

## No local databases

Jobs arrive fully specified: a collector, or the cloud through SKBridge, posts
the label data with the request and this renders it. There is nothing to look
up, so the settings file has no database paths to set.

The label store is written by **SKReceiver**, which is not part of this
package. The print ledger is a local history of what came out; the cloud
already holds that record for work it sent.

## Install

```bash
sudo apt install ./skprinter_1.2.3_arm64.deb
sudoedit /var/lib/skprinter/settings.json     # point it at your printer
sudo systemctl restart skprinter
curl http://localhost:19838/api/health
```

The shipped address is `192.0.2.10` — a documentation address that never
answers, so a forgotten edit times out loudly rather than looking like it
worked.

| Path | |
|---|---|
| `/usr/lib/skprinter/` | binary, native libs, `fonts.conf` (read-only) |
| `/var/lib/skprinter/` | `settings.json`, templates (yours; survives upgrades) |
| `/usr/share/skprinter/` | pristine seed copies |
| `journalctl -u skprinter -f` | live log |

`apt remove` keeps `/var/lib/skprinter`; `apt purge` deletes it.

## Configuration

An unknown key at the top level or inside a `printers` entry is an error, not
something skipped: the service refuses to start and names the member. A
settings file written for the Windows service fails on `adapters`, and a
mistyped `adress` fails rather than leaving a printer with no address. Keys
inside `labelOptions` are the exception — that entry is the shared type both
hosts read, and it is lenient.

```jsonc
"printers": [
  {
    "address": "192.168.1.50:9100",
    "dpi": 203,                       // 203 when omitted (8 dots/mm)
    "darknessAdjustment": null,       // -30..+30 on top of the printer's own
                                      // darkness; null leaves it alone
    "continuousMedia": false          // true emits ^LL; gap/notch media calibrates itself
  }
]
```

`address` is `host`, `host:port` (9100 when the port is left off) or an
absolute device path. It is read as written and never guessed — a mistyped
device path fails as a device path instead of going looking for a host by that
name.

A label profile's `printerName` override names one of these addresses and picks
up that printer's `dpi` and `darknessAdjustment` too, so a profile routed to a
300 dpi printer is rasterized for one. It has to be one of them: an address
that is not configured is rejected at startup, and `POST /api/print` refuses a
`printerName` the file does not list.

Relative paths resolve against the settings file's own directory. Label
profiles hot-reload when pushed through `/api/labelconfig`, and so do the
printers when saved through `/api/settings`. `webApiPort` is the one field a
restart is needed for.

## The HTTP surface

| | |
|---|---|
| `GET /api/health` | checks per printer and per template, plus process uptime |
| `GET /api/config` | profiles, port, machine name |
| `GET /api/machineName` | the name this appliance answers to |
| `GET /api/logs/{max}` | the in-memory log ring, newest first |
| `GET /api/activity` | recent labels and the count printed in the last hour |
| `POST /api/print` | bind data into a profile and print it, on a configured printer |
| `GET /api/labelconfig/{profile}/fields` | the field names that profile's template binds |
| `POST /api/labelconfig` | apply a pushed template (loopback only) |
| `GET /api/settings` | the settings file (loopback only) |
| `POST /api/settings` | replace the settings file (loopback only) |

The three loopback-only endpoints are the administrative ones. There is no
password on them: `skbridge` runs on this machine and is what reaches them.
They are also outside the CORS policy, so a page in a browser on this machine
cannot call them either.

Health always answers 200 — SKBridge reads any other status as "service down",
and a missing template must not look like an unreachable process. A device node
is checked for existence, an unplugged USB printer being the common failure,
while a network address is reported without being dialled, since polling health
should not knock on every printer on the floor.

## Connecting a USB Zebra

The supported transport is the network one. USB works and is genuinely useful
on a bench, but it pins the appliance to the printer's physical location and
gives up the status query — see *What USB costs*.

Zebras present a standard USB printer-class interface, so Linux's in-tree
`usblp` driver binds them and the printer appears as a character device. No
CUPS, no driver, no PPD.

**1 — plug it in and confirm the kernel took it**

```bash
lsusb | grep -i zebra          # e.g. ID 0a5f:0164 Zebra Technologies
ls -l /dev/usb/lp*             # crw-rw---- 1 root lp 180, 0 ... /dev/usb/lp0
dmesg | tail | grep -i usblp
```

No `/dev/usb/lp0`? Either CUPS grabbed the device (see below) or the module is
not loaded — `sudo modprobe usblp`.

**2 — prove it prints, before involving the service**

```bash
printf '^XA^FO50,50^A0N,40,40^FDSKPRINTER OK^FS^XZ\n' | sudo tee /dev/usb/lp0 >/dev/null
```

A label should come out. If it does not, stop here — nothing downstream will
fix a printer that ignores raw ZPL.

**3 — give it a stable name.** `/dev/usb/lp0` is enumeration order, so two
printers can swap across a reboot. Key a symlink off the serial:

```bash
udevadm info -a -n /dev/usb/lp0 | grep -m1 ATTRS{serial}
```

```udev
# /etc/udev/rules.d/60-skprinter.rules
SUBSYSTEM=="usbmisc", ATTRS{serial}=="XXXXXXXXXXXX", SYMLINK+="zebra-1", GROUP="lp", MODE="0660"
```

```bash
sudo udevadm control --reload && sudo udevadm trigger
ls -l /dev/zebra-1
```

**4 — let the service reach it.** The device belongs to group `lp`, so
`SupplementaryGroups=lp` is the line that matters; it ships commented out.
`DeviceAllow=` is optional narrowing, not a requirement — with no entry at
all every device is already permitted — and systemd resolves its path when
the unit starts, so a printer unplugged at boot is denied when it comes
back. Nothing in the unit hides `/dev`: `ProtectSystem=strict` leaves the
API filesystems alone.

```bash
sudo systemctl edit skprinter
```

```ini
[Service]
SupplementaryGroups=lp
DeviceAllow=/dev/zebra-1 rw
```

**5 — point a printer entry at it** in `settings.json`, then restart:

```jsonc
{ "address": "/dev/zebra-1", "dpi": 203 }
```

### If CUPS is installed

Its usb backend unbinds `usblp` to claim the device, so `/dev/usb/lp0`
vanishes. The two approaches are mutually exclusive per printer. Either remove
CUPS, or use it instead with a raw queue (`lpadmin -m raw` + `lp -o raw`) — but
raw queues have been deprecated since CUPS 2.2 and drivers since 2.3, which is
a lot of moving parts to inherit for something a file write already does.

### What USB costs

- **The appliance has to sit at the printer.** That partly undoes the point of
  retiring the office PC: instead of a PC by the printer, an appliance by the
  printer. Network Zebras keep the appliance free-standing and let one serve
  every printer on the LAN.
- **No status.** Over IP a printer answers `~HQES` on the same raw port and its
  print server exposes the Printer MIB over SNMP, so paper-out and head-open
  are recoverable. Neither is implemented yet, and neither is reachable this
  way.

## Fonts

The unit points `FONTCONFIG_FILE` at the package's own `fonts.conf`, which pins
`Arial` / `Helvetica` / `sans-serif` / `sans` to Liberation Sans. This is not
cosmetic: templates ask for `Arial, Helvetica, sans-serif`, and on a bare
Debian `fc-match sans-serif` answers Liberation **Mono** — every label comes
out monospaced with accents dropped. Scoping it to the variable keeps the
override off the rest of the appliance.

Liberation Sans is metric-compatible with Arial, so layout matches the Windows
service; glyph outlines differ slightly.

## Building it

```bash
dotnet publish SKPrinter.Appliance/SKPrinter.Appliance.csproj -c Release \
    -r linux-arm64
bash SKPrinter.Appliance/pkg/build-deb.sh --version 1.2.3
```

Needs Linux for `dpkg-deb`: WSL, a debian container, or CI. Cross-building the
arm64 package on an amd64 host also needs `binutils-aarch64-linux-gnu`, or the
glibc floor in `Depends:` silently stays at its default instead of being read
from the binaries. Build on the oldest distro you intend to install on.

NativeAOT, the same as `skbridge`: no runtime to ship, and 24 MB against
126 MB for a self-contained JIT publish, which matters on a Pi. Building it
needs `clang` and `zlib1g-dev` on the host.

Svg.Skia's parser is reflection-heavy and carries no trimming annotations, so
a template using an SVG feature no test covers is the risk to watch. CI builds
the package on both architectures but does not yet render a corpus through the
published binary.

## arm64 (Raspberry Pi)

Verified end to end: a Pi rendered a label and printed it to a USB Zebra.

Getting there needed the `LD_PRELOAD` line in the unit.
`SkiaSharp.NativeAssets.Linux` 3.119.2's aarch64 `libSkiaSharp.so` calls
fontconfig, freetype and libuuid without declaring any of them as `NEEDED`
(the x86-64 build of the same package is linked correctly), so the loader never
brings them in and the first render dies with
`undefined symbol: FT_Get_BDF_Property`. Preloading supplies the symbols, and
is harmless on x86-64 where they are already loaded.

A crash under QEMU with the preload in place turned out to be emulation, not
aarch64: the real Pi renders fine. Do not read an emulated failure as a
hardware verdict.

The sturdier fix is `SkiaSharp.NativeAssets.Linux.NoDependencies`, which has no
undefined symbols on either architecture — but it drops fontconfig with them,
so fonts would have to be pinned in code
(`SKSvg.Settings.TypefaceProviders`) instead of by `fonts.conf`. That is a
change to the binder, so it wants a decision rather than a quiet swap.

## Known gaps

- Rotation (`^PO` / `^FW`) is not applied: a template that declares a rotated
  raster prints unrotated. Affects the Windows build the same way.
- An `<image>` slot whose geometry carries no `mm` suffix is dropped, because
  the binder's measurement requires the unit. Also shared with Windows.
- No printer status. `~HQES` over the raw port and the Printer MIB over SNMP
  would both make paper-out and head-open recoverable; neither is implemented.
